package app.neonsignal;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.IBinder;

import java.lang.ref.WeakReference;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * "Turbo": the modem drops to idle after a few seconds without traffic, and the next request
 * waits until it reconnects to the tower. A tiny DNS query every few seconds keeps it connected.
 */
public class TurboService extends Service {
    static final String CH = "turbo", ACT_STOP = "app.neonsignal.STOP_TURBO";
    static final int NID = 5;
    static final long PERIOD_S = 4;
    static volatile boolean running;
    static WeakReference<MainActivity> activity = new WeakReference<>(null);
    private ScheduledExecutorService timer;
    private DatagramSocket sock;

    static void start(Context c) { try { c.startForegroundService(new Intent(c, TurboService.class)); } catch (Exception ignored) { } }

    static void stop(Context c) { c.stopService(new Intent(c, TurboService.class)); }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACT_STOP.equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        Notification n = notification();
        try {
            if (Build.VERSION.SDK_INT >= 34) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            else startForeground(NID, n);
        } catch (Exception e) { stopSelf(); return START_NOT_STICKY; }
        if (timer == null) {
            timer = Executors.newSingleThreadScheduledExecutor();
            timer.scheduleWithFixedDelay(this::keepAlive, 0, PERIOD_S, TimeUnit.SECONDS);
        }
        running = true;
        MainActivity a = activity.get();
        if (a != null) a.emitTurbo();
        return START_STICKY;
    }

    /** a DNS query for "ya.ru" over the mobile network, only when mobile is the active connection */
    private void keepAlive() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            Network net = cm.getActiveNetwork();
            NetworkCapabilities nc = net != null ? cm.getNetworkCapabilities(net) : null;
            if (nc == null || !nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) || nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return;
            if (sock == null || sock.isClosed()) { sock = new DatagramSocket(); sock.setSoTimeout(1500); }
            byte[] q = {0x4e, 0x53, 0x01, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 'y', 'a', 0x02, 'r', 'u', 0x00, 0x00, 0x01, 0x00, 0x01};
            sock.send(new DatagramPacket(q, q.length, InetAddress.getByAddress(new byte[]{77, 88, 8, 8}), 53));
            byte[] buf = new byte[512];
            try { sock.receive(new DatagramPacket(buf, buf.length)); } catch (Exception ignored) { }
        } catch (Exception e) {
            try { if (sock != null) sock.close(); } catch (Exception ignored) { }
            sock = null;
        }
    }

    private Notification notification() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm.getNotificationChannel(CH) == null) {
            NotificationChannel ch = new NotificationChannel(CH, "Турбо‑режим", NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
        PendingIntent open = PendingIntent.getActivity(this, 1, new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop = PendingIntent.getService(this, 2, new Intent(this, TurboService.class).setAction(ACT_STOP), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, CH)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Турбо‑режим включён")
                .setContentText("Модем не засыпает: страницы откликаются быстрее")
                .setOngoing(true)
                .setShowWhen(false)
                .setContentIntent(open)
                .addAction(new Notification.Action.Builder(null, "Выключить", stop).build())
                .build();
    }

    @Override
    public void onDestroy() {
        if (timer != null) { timer.shutdownNow(); timer = null; }
        try { if (sock != null) sock.close(); } catch (Exception ignored) { }
        sock = null;
        running = false;
        MainActivity a = activity.get();
        if (a != null) a.emitTurbo();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent i) { return null; }
}
