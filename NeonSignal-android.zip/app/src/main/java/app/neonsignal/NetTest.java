package app.neonsignal;

import android.net.Network;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Latency (ICMP ping, TCP fallback) and download/upload speed measurements. */
final class NetTest {
    interface Out { void emit(JSONObject e); }

    static final String UA = "NeonSignal/" + BuildConfig.VERSION_NAME + " (Android)";
    private final Out out;
    private final ExecutorService pool = Executors.newCachedThreadPool();
    private volatile boolean stop;

    NetTest(Out out, NetPick pick) { this.out = out; this.pick = pick; }

    private static void put(JSONObject o, String k, Object v) { try { o.put(k, v); } catch (Exception ignored) { } }

    /* ======================= ping ======================= */
    interface NetPick { Network get(); }

    /** where tests go: null = the default network (already mobile), else the mobile network next to Wi-Fi */
    private final NetPick pick;
    private volatile String via = "cell";

    void setVia(String v) { via = v; }

    void ping(String id, String host, int count) {
        pool.execute(() -> {
            Network n = pick.get();
            List<Double> rtts = new ArrayList<>();
            int sent = n == null ? icmp(id, host, count, rtts) : 0;
            if (sent == 0) sent = tcp(id, host, count, rtts, n);
            report(id, count, rtts, Math.max(sent, count), true);
        });
    }

    private void report(String id, int total, List<Double> rtts, int sent, boolean done) {
        JSONObject e = new JSONObject();
        put(e, "type", "ping"); put(e, "id", id); put(e, "total", total); put(e, "done", done); put(e, "via", via);
        if (!rtts.isEmpty()) {
            double sum = 0, min = Double.MAX_VALUE, max = 0, jit = 0;
            for (int i = 0; i < rtts.size(); i++) {
                double v = rtts.get(i);
                sum += v; min = Math.min(min, v); max = Math.max(max, v);
                if (i > 0) jit += Math.abs(v - rtts.get(i - 1));
            }
            put(e, "avg", sum / rtts.size()); put(e, "min", min); put(e, "max", max);
            put(e, "jitter", rtts.size() > 1 ? jit / (rtts.size() - 1) : 0);
            put(e, "last", rtts.get(rtts.size() - 1));
        }
        int lost = Math.max(0, sent - rtts.size());
        put(e, "loss", done ? (int) Math.round(lost * 100.0 / Math.max(1, sent)) : 0);
        out.emit(e);
    }

    private static final Pattern TIME = Pattern.compile("time[=<]([0-9.]+)\\s*ms");

    /** the system ping binary works for normal apps on Android (unprivileged ICMP sockets) */
    private int icmp(String id, String host, int count, List<Double> rtts) {
        Process p = null;
        try {
            p = new ProcessBuilder("ping", "-c", String.valueOf(count), "-i", "0.2", "-W", "1", host).redirectErrorStream(true).start();
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            int seen = 0;
            boolean valid = false;
            long deadline = System.currentTimeMillis() + count * 1200L + 3000;
            while ((line = r.readLine()) != null) {
                if (line.contains("packets transmitted") || line.startsWith("PING")) valid = true;
                Matcher m = TIME.matcher(line);
                if (m.find()) {
                    rtts.add(Double.parseDouble(m.group(1)));
                    seen++;
                    report(id, count, rtts, seen, false);
                }
                if (System.currentTimeMillis() > deadline) break;
            }
            p.waitFor(2, TimeUnit.SECONDS);
            return valid || !rtts.isEmpty() ? count : 0;
        } catch (Exception e) {
            return 0;
        } finally { if (p != null) p.destroy(); }
    }

    /** fallback: time of a TCP handshake */
    private int tcp(String id, String host, int count, List<Double> rtts, Network n) {
        int[] ports = {53, 80, 443};
        int port = -1;
        for (int pt : ports) { if (connectMs(host, pt, 1500, n) >= 0) { port = pt; break; } }
        if (port < 0) return count;
        for (int i = 0; i < count; i++) {
            double ms = connectMs(host, port, 1500, n);
            if (ms >= 0) rtts.add(ms);
            report(id, count, rtts, i + 1, false);
            try { Thread.sleep(150); } catch (InterruptedException ignored) { }
        }
        return count;
    }

    /** time of a TCP handshake; DNS and the socket both go through the chosen network */
    static double connectMs(String host, int port, int timeout, Network n) {
        try {
            InetAddress a = n != null ? n.getByName(host) : InetAddress.getByName(host);
            try (Socket s = new Socket()) {
                if (n != null) n.bindSocket(s);
                long t = System.nanoTime();
                s.connect(new InetSocketAddress(a, port), timeout);
                return (System.nanoTime() - t) / 1e6;
            }
        } catch (Exception e) { return -1; }
    }

    @SuppressWarnings("deprecation")
    private static HttpURLConnection open(String url, Network n) throws java.io.IOException {
        URL u = new URL(url);
        return (HttpURLConnection) (n != null ? n.openConnection(u) : u.openConnection());
    }

    /* ======================= speed ======================= */
    static final String[][] SERVERS = {
            {"Selectel, Россия", "speedtest.selectel.ru", "https://speedtest.selectel.ru/100MB", ""},
            {"Cloudflare", "speed.cloudflare.com", "https://speed.cloudflare.com/__down?bytes=100000000", "https://speed.cloudflare.com/__up"},
    };

    void speedStop() { stop = true; }

    void speed() {
        stop = false;
        pool.execute(() -> {
            try {
                Network n = pick.get();
                // pick the server that answers fastest
                String[] best = null;
                double bestMs = Double.MAX_VALUE;
                for (String[] s : SERVERS) {
                    double ms = connectMs(s[1], 443, 3000, n);
                    if (ms >= 0 && ms < bestMs) { bestMs = ms; best = s; }
                }
                if (best == null) { fail("Нет соединения с интернетом"); return; }
                List<Double> rtts = new ArrayList<>();
                for (int i = 0; i < 6 && !stop; i++) { double ms = connectMs(best[1], 443, 3000, n); if (ms >= 0) rtts.add(ms); }
                double ping = rtts.isEmpty() ? bestMs : min(rtts), jit = 0;
                for (int i = 1; i < rtts.size(); i++) jit += Math.abs(rtts.get(i) - rtts.get(i - 1));
                if (rtts.size() > 1) jit /= rtts.size() - 1;
                JSONObject e = ev("ping"); put(e, "ping", ping); put(e, "jitter", jit); put(e, "server", best[0]); out.emit(e);
                if (stop) return;
                double down = download(best[2], 10_000, n);
                if (stop) return;
                if (down <= 0) { fail("Не удалось скачать тестовый файл"); return; }
                String upUrl = best[3].isEmpty() ? SERVERS[1][3] : best[3];
                double up = upload(upUrl, 8_000, down, n);
                JSONObject d = ev("done");
                put(d, "down", down); put(d, "ping", ping); put(d, "jitter", jit); put(d, "server", best[0]);
                if (up > 0) put(d, "up", up);
                out.emit(d);
            } catch (Exception ex) { fail("Ошибка теста: " + ex.getMessage()); }
        });
    }

    private static double min(List<Double> l) { double m = Double.MAX_VALUE; for (double v : l) m = Math.min(m, v); return m; }

    private JSONObject ev(String phase) { JSONObject e = new JSONObject(); put(e, "type", "speed"); put(e, "phase", phase); put(e, "via", via); return e; }

    private void fail(String msg) { JSONObject e = ev("error"); put(e, "error", msg); out.emit(e); }

    /** Mbit/s measured after the first second (TCP slow start excluded) */
    private double download(String url, long ms, Network n) throws InterruptedException {
        AtomicLong bytes = new AtomicLong();
        long t0 = System.currentTimeMillis();
        ExecutorService ws = Executors.newFixedThreadPool(4);
        for (int i = 0; i < 4; i++) ws.execute(() -> {
            while (!stop && System.currentTimeMillis() - t0 < ms) {
                HttpURLConnection c = null;
                try {
                    c = open(url, n);
                    c.setConnectTimeout(5000); c.setReadTimeout(5000);
                    c.setRequestProperty("User-Agent", UA);
                    c.setRequestProperty("Accept-Encoding", "identity");
                    c.setUseCaches(false);
                    if (c.getResponseCode() != 200) return;
                    try (InputStream in = c.getInputStream()) {
                        byte[] buf = new byte[65536];
                        int k;
                        while (!stop && (k = in.read(buf)) > 0) {
                            bytes.addAndGet(k);
                            if (System.currentTimeMillis() - t0 >= ms) break;
                        }
                    }
                } catch (Exception e) {
                    return;
                } finally { if (c != null) c.disconnect(); }
            }
        });
        ws.shutdown();
        return track(ws, bytes, t0, ms, "down", -1);
    }

    private double track(ExecutorService ws, AtomicLong bytes, long t0, long ms, String phase, double down) throws InterruptedException {
        long b1 = -1, t1 = 0, lastB = 0, lastT = t0;
        double cur = 0;
        while (!ws.awaitTermination(250, TimeUnit.MILLISECONDS)) {
            long now = System.currentTimeMillis(), b = bytes.get();
            if (b1 < 0 && now - t0 >= 1000) { b1 = b; t1 = now; }
            double inst = (b - lastB) * 8.0 / Math.max(1, now - lastT) / 1000.0;
            cur = cur == 0 ? inst : cur * 0.7 + inst * 0.3;
            lastB = b; lastT = now;
            JSONObject e = ev(phase); put(e, "mbps", cur); put(e, "progress", Math.min(1.0, (now - t0) / (double) ms));
            if (down > 0) put(e, "down", down);
            out.emit(e);
            if (now - t0 > ms + 3000) { ws.shutdownNow(); break; }
        }
        long now = System.currentTimeMillis(), b = bytes.get();
        if (b1 < 0 || now - t1 < 500) return b * 8.0 / Math.max(1, now - t0) / 1000.0;
        return (b - b1) * 8.0 / (now - t1) / 1000.0;
    }

    private double upload(String url, long ms, double down, Network n) {
        try {
            AtomicLong bytes = new AtomicLong();
            long t0 = System.currentTimeMillis();
            byte[] chunk = new byte[65536];
            new Random().nextBytes(chunk);
            ExecutorService ws = Executors.newFixedThreadPool(3);
            for (int i = 0; i < 3; i++) ws.execute(() -> {
                while (!stop && System.currentTimeMillis() - t0 < ms) {
                    HttpURLConnection c = null;
                    try {
                        c = open(url, n);
                        c.setConnectTimeout(5000); c.setReadTimeout(8000);
                        c.setDoOutput(true);
                        c.setRequestMethod("POST");
                        c.setRequestProperty("User-Agent", UA);
                        c.setRequestProperty("Content-Type", "application/octet-stream");
                        int size = 8 << 20;
                        c.setFixedLengthStreamingMode(size);
                        try (OutputStream o = c.getOutputStream()) {
                            int sent = 0;
                            while (!stop && sent < size) {
                                int k = Math.min(chunk.length, size - sent);
                                o.write(chunk, 0, k);
                                sent += k;
                                bytes.addAndGet(k);
                                if (System.currentTimeMillis() - t0 >= ms) break;
                            }
                        }
                        c.getResponseCode();
                    } catch (Exception e) {
                        if (bytes.get() == 0) return;
                    } finally { if (c != null) c.disconnect(); }
                }
            });
            ws.shutdown();
            double r = track(ws, bytes, t0, ms, "up", down);
            return bytes.get() > 0 ? r : -1;
        } catch (Exception e) { return -1; }
    }
}
