package app.neonsignal;

import android.content.Context;
import android.os.Build;
import android.telephony.PhoneStateListener;
import android.telephony.ServiceState;
import android.telephony.SignalStrength;
import android.telephony.TelephonyCallback;
import android.telephony.TelephonyDisplayInfo;
import android.telephony.TelephonyManager;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;

/** Signal, service state (carrier aggregation) and 5G display info of one SIM, on every Android version. */
final class Tele {
    interface Sink {
        void display(int netType, int override);
        void service(int state, int[] bandwidths);
        void signal();
    }

    private final TelephonyManager t;
    private final List<Object> handles = new ArrayList<>();

    Tele(TelephonyManager t) { this.t = t; }

    @SuppressWarnings("deprecation")
    void start(Context ctx, Sink s, boolean phonePerm) {
        if (Build.VERSION.SDK_INT >= 31) {
            Executor ex = ctx.getMainExecutor();
            reg(new SigCb(s), ex);
            reg(new SvcCb(s), ex);
            reg(new DispCb(s), ex);
        } else {
            Legacy l = new Legacy(s);
            try { t.listen(l, PhoneStateListener.LISTEN_SIGNAL_STRENGTHS | PhoneStateListener.LISTEN_SERVICE_STATE); handles.add(l); } catch (Exception ignored) { }
            if (Build.VERSION.SDK_INT == 30 && phonePerm) {
                Legacy d = new Legacy(s);
                try { t.listen(d, PhoneStateListener.LISTEN_DISPLAY_INFO_CHANGED); handles.add(d); } catch (Exception ignored) { }
            }
        }
    }

    private void reg(Object cb, Executor ex) {
        try { t.registerTelephonyCallback(ex, (TelephonyCallback) cb); handles.add(cb); } catch (Exception ignored) { }
    }

    @SuppressWarnings("deprecation")
    void stop() {
        for (Object h : handles) {
            try {
                if (Build.VERSION.SDK_INT >= 31 && h instanceof TelephonyCallback) t.unregisterTelephonyCallback((TelephonyCallback) h);
                else if (h instanceof PhoneStateListener) t.listen((PhoneStateListener) h, PhoneStateListener.LISTEN_NONE);
            } catch (Exception ignored) { }
        }
        handles.clear();
    }

    static int[] bandwidths(ServiceState ss) {
        if (ss == null || Build.VERSION.SDK_INT < 28) return null;
        try { return ss.getCellBandwidths(); } catch (Exception e) { return null; }
    }

    static final class SigCb extends TelephonyCallback implements TelephonyCallback.SignalStrengthsListener {
        final Sink s;
        SigCb(Sink s) { this.s = s; }
        @Override public void onSignalStrengthsChanged(SignalStrength ss) { s.signal(); }
    }

    static final class SvcCb extends TelephonyCallback implements TelephonyCallback.ServiceStateListener {
        final Sink s;
        SvcCb(Sink s) { this.s = s; }
        @Override public void onServiceStateChanged(ServiceState ss) { s.service(ss.getState(), bandwidths(ss)); }
    }

    static final class DispCb extends TelephonyCallback implements TelephonyCallback.DisplayInfoListener {
        final Sink s;
        DispCb(Sink s) { this.s = s; }
        @Override public void onDisplayInfoChanged(TelephonyDisplayInfo d) { s.display(d.getNetworkType(), d.getOverrideNetworkType()); }
    }

    @SuppressWarnings("deprecation")
    static final class Legacy extends PhoneStateListener {
        final Sink s;
        Legacy(Sink s) { this.s = s; }
        @Override public void onSignalStrengthsChanged(SignalStrength ss) { s.signal(); }
        @Override public void onServiceStateChanged(ServiceState ss) { s.service(ss.getState(), bandwidths(ss)); }
        @Override public void onDisplayInfoChanged(TelephonyDisplayInfo d) { s.display(d.getNetworkType(), d.getOverrideNetworkType()); }
    }
}
