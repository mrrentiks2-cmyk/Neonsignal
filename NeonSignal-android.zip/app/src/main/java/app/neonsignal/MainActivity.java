package app.neonsignal;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.telephony.CellIdentity;
import android.telephony.CellInfo;
import android.telephony.CellInfoGsm;
import android.telephony.CellInfoLte;
import android.telephony.CellInfoNr;
import android.telephony.CellInfoTdscdma;
import android.telephony.CellInfoWcdma;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity implements Tele.Sink {
    static final String HOST = "appassets.androidplatform.net";
    static final int REQ_PERM = 11, REQ_NOTIF = 13;

    WebView web;
    TelephonyManager tm;
    SubscriptionManager sm;
    ConnectivityManager cm;
    NetTest net;
    SharedPreferences prefs;
    final Handler ui = new Handler(Looper.getMainLooper());
    final ExecutorService bg = Executors.newSingleThreadExecutor();
    volatile int insetTop;
    boolean resumed, receiversOn;
    volatile boolean live, forceCells;

    // live info about the data SIM from telephony callbacks
    volatile int dataSub = -2, dispType, dispOvr, svcState = -1;
    volatile int[] bws;
    Tele tele;
    String lastSig = "", lastCells = "", lastState = "";
    long lastCellsAt, lastStateAt, lastCellsEmit;

    ConnectivityManager.NetworkCallback defCb;

    final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!resumed) return;
            long now = SystemClock.elapsedRealtime();
            emitSig(false);
            if (now - lastCellsAt >= (live ? 2000 : 4000)) { lastCellsAt = now; requestCells(); }
            if (now - lastStateAt >= 5000) { lastStateAt = now; emitState(false); }
            ui.postDelayed(this, live ? 1000 : 2000);
        }
    };

    final Runnable stateSoon = () -> emitState(true);

    final BroadcastReceiver rx = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            ui.removeCallbacks(stateSoon);
            ui.postDelayed(stateSoon, Intent.ACTION_AIRPLANE_MODE_CHANGED.equals(i.getAction()) ? 50 : 300);
            if (Intent.ACTION_AIRPLANE_MODE_CHANGED.equals(i.getAction())) forceCells = true;
        }
    };

    @Override
    @SuppressWarnings("deprecation")
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("app", MODE_PRIVATE);
        tm = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        sm = (SubscriptionManager) getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
        cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        net = new NetTest(this::emit, this::pickNet);
        TurboService.activity = new WeakReference<>(this);

        Window w = getWindow();
        w.setStatusBarColor(Color.TRANSPARENT);
        w.setNavigationBarColor(0xFF07070E);
        w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        w.getDecorView().setOnApplyWindowInsetsListener((v, ins) -> { insetTop = ins.getSystemWindowInsetTop(); return v.onApplyWindowInsets(ins); });

        if ((getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0) WebView.setWebContentsDebuggingEnabled(true);
        web = new WebView(this);
        web.setBackgroundColor(0xFF07070E);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setTextZoom(100);
        s.setMediaPlaybackRequiresUserGesture(false);
        WebViewAssetLoader loader = new WebViewAssetLoader.Builder().setDomain(HOST).addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) { return loader.shouldInterceptRequest(req.getUrl()); }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                if (HOST.equals(req.getUrl().getHost())) return false;
                openUrl(req.getUrl().toString());
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "W");
        defCb = new ConnectivityManager.NetworkCallback() {
            @Override public void onAvailable(Network n) { stateLater(); }
            @Override public void onLost(Network n) { stateLater(); }
            @Override public void onCapabilitiesChanged(Network n, NetworkCapabilities nc) { stateLater(); }
        };
        try { cm.registerDefaultNetworkCallback(defCb); } catch (Exception ignored) { }
        watchDataSim();
        web.loadUrl("https://" + HOST + "/assets/www/index.html");
    }

    void stateLater() { ui.removeCallbacks(stateSoon); ui.postDelayed(stateSoon, 400); }

    /* ======================= events ======================= */
    void emit(JSONObject e) {
        final String js = "window.__wEvent && window.__wEvent(" + JSONObject.quote(e.toString()) + ")";
        ui.post(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    void emitTurbo() { try { emit(new JSONObject().put("type", "turbo").put("on", TurboService.running)); } catch (Exception ignored) { } }

    void emitState(boolean always) {
        bg.execute(() -> {
            String s = state().toString();
            if (!always && s.equals(lastState)) return;
            lastState = s;
            try { emit(new JSONObject().put("type", "state").put("state", new JSONObject(s))); } catch (Exception ignored) { }
        });
    }

    void emitSig(boolean always) {
        bg.execute(() -> {
            int sub = dataSub;
            JSONObject s = sigOf(sub < 0 ? tm : tm.createForSubscriptionId(sub));
            if (s == null) return;
            String k = s.toString();
            if (!always && k.equals(lastSig)) return;
            lastSig = k;
            try { emit(new JSONObject().put("type", "sig").put("sub", sub).put("sig", s)); } catch (Exception ignored) { }
        });
    }

    void emitCells(List<CellInfo> list) {
        String s = Radio.cells(list).toString();
        long now = SystemClock.elapsedRealtime();
        if (!forceCells && s.equals(lastCells) && now - lastCellsEmit < 15000) return;
        forceCells = false; lastCells = s; lastCellsEmit = now;
        try { emit(new JSONObject().put("type", "cells").put("list", new JSONArray(s))); } catch (Exception ignored) { }
    }

    /* ======================= telephony callbacks (Tele.Sink) ======================= */
    @Override public void display(int netType, int override) { dispType = netType; dispOvr = override; stateLater(); }
    @Override public void service(int state, int[] b) { svcState = state; bws = b; stateLater(); }
    @Override public void signal() { emitSig(false); }

    /** follow the SIM that carries mobile data */
    void watchDataSim() {
        int sub = SubscriptionManager.getDefaultDataSubscriptionId();
        if (sub == dataSub && tele != null) return;
        if (tele != null) tele.stop();
        dataSub = sub; dispType = 0; dispOvr = 0; bws = null; svcState = -1;
        TelephonyManager t = sub < 0 ? tm : tm.createForSubscriptionId(sub);
        tele = new Tele(t);
        tele.start(this, this, phonePerm());
    }

    /* ======================= data ======================= */
    boolean fine() { return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED; }

    boolean phonePerm() { return checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED; }

    boolean locOn() {
        try {
            LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            return Build.VERSION.SDK_INT >= 28 ? lm.isLocationEnabled() : lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) || lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
        } catch (Exception e) { return true; }
    }

    boolean airplane() { return Settings.Global.getInt(getContentResolver(), Settings.Global.AIRPLANE_MODE_ON, 0) != 0; }

    String perm() {
        if (fine()) return "granted";
        boolean asked = prefs.getBoolean("askedPerm", false);
        if (!asked || shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION)) return "ask";
        return "denied";
    }

    @SuppressWarnings("deprecation")
    String simState() {
        try {
            int n = Build.VERSION.SDK_INT >= 30 ? tm.getActiveModemCount() : tm.getPhoneCount();
            int absent = 0, locked = 0;
            for (int i = 0; i < Math.max(1, n); i++) {
                int st = tm.getSimState(i);
                if (st == TelephonyManager.SIM_STATE_READY) return "ready";
                if (st == TelephonyManager.SIM_STATE_ABSENT) absent++;
                if (st == TelephonyManager.SIM_STATE_PIN_REQUIRED || st == TelephonyManager.SIM_STATE_PUK_REQUIRED || st == TelephonyManager.SIM_STATE_NETWORK_LOCKED) locked++;
            }
            return locked > 0 ? "locked" : absent >= Math.max(1, n) ? "absent" : "unknown";
        } catch (Exception e) { return "unknown"; }
    }

    /** what carries the internet right now: cell / wifi / other / none */
    @SuppressWarnings("deprecation")
    String defNet() {
        try {
            Network n = cm.getActiveNetwork();
            NetworkCapabilities nc = n != null ? cm.getNetworkCapabilities(n) : null;
            if (nc == null) return "none";
            if (nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return "wifi";
            if (nc.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) {
                for (Network x : cm.getAllNetworks()) {
                    NetworkCapabilities c = cm.getNetworkCapabilities(x);
                    if (c != null && c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) return "wifi";
                }
                return "cell";
            }
            if (nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) return "cell";
            return "other";
        } catch (Exception e) { return "none"; }
    }

    boolean plainCellDefault() {
        try {
            Network n = cm.getActiveNetwork();
            NetworkCapabilities nc = n != null ? cm.getNetworkCapabilities(n) : null;
            return nc != null && nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) && !nc.hasTransport(NetworkCapabilities.TRANSPORT_VPN) && !nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);
        } catch (Exception e) { return false; }
    }

    JSONObject state() {
        JSONObject o = new JSONObject();
        try {
            watchDataSimFromBg();
            o.put("perm", perm());
            o.put("phone", phonePerm());
            o.put("locOn", locOn());
            o.put("sdk", Build.VERSION.SDK_INT);
            o.put("air", airplane());
            o.put("sim", simState());
            o.put("def", defNet());
            try { o.put("dataOn", tm.isDataEnabled()); } catch (Exception ignored) { }
            try { o.put("saver", cm.getRestrictBackgroundStatus() == ConnectivityManager.RESTRICT_BACKGROUND_STATUS_ENABLED); } catch (Exception ignored) { }
            try { int s = dataSub; o.put("roaming", (s < 0 ? tm : tm.createForSubscriptionId(s)).isNetworkRoaming()); } catch (Exception ignored) { }
            o.put("sims", sims());
            o.put("turbo", TurboService.running);
        } catch (Exception ignored) { }
        return o;
    }

    void watchDataSimFromBg() {
        if (SubscriptionManager.getDefaultDataSubscriptionId() != dataSub) ui.post(this::watchDataSim);
    }

    JSONArray sims() {
        JSONArray a = new JSONArray();
        int data = SubscriptionManager.getDefaultDataSubscriptionId();
        List<SubscriptionInfo> subs = null;
        if (phonePerm()) { try { subs = sm.getActiveSubscriptionInfoList(); } catch (Exception ignored) { } }
        if (subs != null && !subs.isEmpty()) {
            for (SubscriptionInfo si : subs) {
                int id = si.getSubscriptionId();
                boolean isData = id == data || (data < 0 && subs.size() == 1);
                a.put(sim(tm.createForSubscriptionId(id), id, si.getSimSlotIndex(), String.valueOf(si.getDisplayName()), isData));
            }
        } else if (simState().equals("ready") || tm.getNetworkOperator() != null && !tm.getNetworkOperator().isEmpty()) {
            a.put(sim(data < 0 ? tm : tm.createForSubscriptionId(data), data, 0, null, true));
        }
        return a;
    }

    @SuppressWarnings("deprecation")
    JSONObject sim(TelephonyManager t, int sub, int slot, String name, boolean data) {
        JSONObject o = new JSONObject();
        try {
            o.put("sub", sub); o.put("slot", Math.max(0, slot)); o.put("data", data);
            if (name != null && !name.isEmpty() && !"null".equals(name)) o.put("name", name);
            String op = t.getNetworkOperatorName(), code = t.getNetworkOperator();
            if (op != null && !op.isEmpty()) o.put("op", op);
            if (code != null && code.length() >= 5) o.put("mccmnc", code);
            int rat = 0;
            if (data) {
                try { rat = t.getDataNetworkType(); } catch (Exception ignored) { }
                if (rat == 0) rat = dispType;
                o.put("ovr", dispOvr);
                int[] b = bws;
                if (b != null && b.length > 0) { JSONArray ba = new JSONArray(); for (int x : b) ba.put(x); o.put("bws", ba); }
                if (svcState >= 0) o.put("svc", svcState);
            } else {
                try { rat = t.getVoiceNetworkType(); } catch (Exception ignored) { }
            }
            if (rat == 19) rat = 13;   // LTE_CA reported by some modems
            o.put("rat", rat);
            JSONObject s = sigOf(t);
            if (s != null) o.put("sig", s);
        } catch (Exception ignored) { }
        return o;
    }

    /** signal of one SIM; Android 9 and older: from its registered cell */
    JSONObject sigOf(TelephonyManager t) {
        try {
            if (Build.VERSION.SDK_INT >= 29) return Radio.sig(t.getSignalStrength());
            if (!fine()) return null;
            List<CellInfo> l = t.getAllCellInfo();
            if (l != null) for (CellInfo c : l) if (c.isRegistered()) {
                JSONObject o = Radio.cell(c);
                if (o != null) { o.remove("reg"); o.remove("st"); return o; }
            }
        } catch (Exception ignored) { }
        return null;
    }

    /** fresh cells for the data SIM plus the registered cell of the other SIM */
    void requestCells() {
        if (!fine()) return;
        int sub = dataSub;
        TelephonyManager t = sub < 0 ? tm : tm.createForSubscriptionId(sub);
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                t.requestCellInfoUpdate(bg, new TelephonyManager.CellInfoCallback() {
                    @Override public void onCellInfo(List<CellInfo> list) { emitCells(merge(list)); }
                    @Override public void onError(int code, Throwable detail) { emitCells(cached()); }
                });
                return;
            } catch (Exception ignored) { }
        }
        bg.execute(() -> emitCells(cached()));
    }

    List<CellInfo> cached() {
        try { List<CellInfo> l = tm.getAllCellInfo(); return l != null ? l : new ArrayList<>(); } catch (Exception e) { return new ArrayList<>(); }
    }

    List<CellInfo> merge(List<CellInfo> fresh) {
        List<CellInfo> out = new ArrayList<>(fresh != null ? fresh : new ArrayList<>());
        for (CellInfo c : cached()) {
            if (!c.isRegistered()) continue;
            Object id = ident(c);
            boolean dup = false;
            for (CellInfo f : out) if (Objects.equals(ident(f), id)) { dup = true; break; }
            if (!dup) out.add(c);
        }
        return out;
    }

    static Object ident(CellInfo c) {
        if (c instanceof CellInfoLte) return ((CellInfoLte) c).getCellIdentity();
        if (c instanceof CellInfoWcdma) return ((CellInfoWcdma) c).getCellIdentity();
        if (c instanceof CellInfoGsm) return ((CellInfoGsm) c).getCellIdentity();
        if (Build.VERSION.SDK_INT >= 29 && c instanceof CellInfoNr) { CellIdentity id = ((CellInfoNr) c).getCellIdentity(); return id; }
        if (Build.VERSION.SDK_INT >= 29 && c instanceof CellInfoTdscdma) return ((CellInfoTdscdma) c).getCellIdentity();
        return c;
    }

    /* ======================= tests over mobile data ======================= */
    private final Object cellLock = new Object();
    private ConnectivityManager.NetworkCallback cellCb;
    private volatile Network leased;
    private long noCellUntil;
    private final Runnable releaseCell = () -> new Thread(this::releaseCell).start();

    /** null = default network is plain mobile; otherwise borrow the mobile network next to Wi-Fi/VPN */
    Network pickNet() {
        if (plainCellDefault()) { net.setVia("cell"); return null; }
        Network n = leaseCell();
        if (n != null) { net.setVia("cell"); return n; }
        net.setVia("wifi".equals(defNet()) ? "wifi" : "cell");
        return null;
    }

    Network leaseCell() {
        synchronized (cellLock) {
            ui.removeCallbacks(releaseCell);
            ui.postDelayed(releaseCell, 60_000);
            if (leased != null) return leased;
            if (SystemClock.elapsedRealtime() < noCellUntil) return null;
            CountDownLatch done = new CountDownLatch(1);
            NetworkRequest req = new NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR).addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build();
            cellCb = new ConnectivityManager.NetworkCallback() {
                @Override public void onAvailable(Network n) { leased = n; done.countDown(); }
                @Override public void onLost(Network n) { if (n.equals(leased)) leased = null; }
                @Override public void onUnavailable() { done.countDown(); }
            };
            try { cm.requestNetwork(req, cellCb, 6000); } catch (Exception e) { cellCb = null; return null; }
            try { done.await(6500, TimeUnit.MILLISECONDS); } catch (InterruptedException ignored) { }
            if (leased == null) { noCellUntil = SystemClock.elapsedRealtime() + 30_000; dropCellCb(); }
            return leased;
        }
    }

    void releaseCell() { synchronized (cellLock) { dropCellCb(); leased = null; } }

    private void dropCellCb() {
        if (cellCb != null) { try { cm.unregisterNetworkCallback(cellCb); } catch (Exception ignored) { } cellCb = null; }
    }

    /* ======================= actions ======================= */
    void openUrl(String u) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
        catch (Exception e) { ui.post(() -> Toast.makeText(this, "Нет приложения, чтобы открыть ссылку", Toast.LENGTH_SHORT).show()); }
    }

    boolean tryStart(Intent... list) {
        for (Intent i : list) {
            if (i == null) continue;
            try { startActivity(i); return true; } catch (Exception ignored) { }
        }
        return false;
    }

    boolean openSettings(String kind) {
        switch (kind) {
            case "air": return tryStart(new Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS), new Intent(Settings.ACTION_WIRELESS_SETTINGS));
            case "mobile": return tryStart(new Intent(Settings.ACTION_DATA_ROAMING_SETTINGS), new Intent(Settings.ACTION_WIRELESS_SETTINGS), new Intent(Settings.ACTION_SETTINGS));
            case "operators": return tryStart(new Intent(Settings.ACTION_NETWORK_OPERATOR_SETTINGS), new Intent(Settings.ACTION_DATA_ROAMING_SETTINGS));
            case "sim": return tryStart(new Intent("android.settings.MANAGE_ALL_SIM_PROFILES_SETTINGS"), new Intent("android.settings.SIM_SETTINGS"), new Intent(Settings.ACTION_DATA_ROAMING_SETTINGS), new Intent(Settings.ACTION_WIRELESS_SETTINGS));
            case "data": return tryStart(Build.VERSION.SDK_INT >= 28 ? new Intent(Settings.ACTION_DATA_USAGE_SETTINGS) : null, new Intent(Settings.ACTION_DATA_ROAMING_SETTINGS));
            case "loc": return tryStart(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
            case "app": return tryStart(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())));
            default: return false;
        }
    }

    /** the hidden "Phone info" screen where the preferred network type can be set */
    String netMode() {
        String[][] comps = {
                {"com.android.phone", "com.android.phone.settings.RadioInfo", "radio"},
                {"com.android.settings", "com.android.settings.RadioInfo", "radio"},
                {"com.android.settings", "com.android.settings.Settings$TestingSettingsActivity", "testing"},
                {"com.android.settings", "com.android.settings.TestingSettings", "testing"},
        };
        for (String[] c : comps) {
            try { startActivity(new Intent(Intent.ACTION_MAIN).setComponent(new ComponentName(c[0], c[1])).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return c[2]; }
            catch (Exception ignored) { }
        }
        try { startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode("*#*#4636#*#*")))); return "dialer"; }
        catch (Exception ignored) { }
        return "fail";
    }

    String lastLocation() {
        if (!fine() && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return "";
        try {
            LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            Location best = null;
            for (String p : lm.getProviders(true)) {
                Location l = lm.getLastKnownLocation(p);
                if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
            }
            return best == null ? "" : new JSONObject().put("lat", best.getLatitude()).put("lon", best.getLongitude()).toString();
        } catch (Exception e) { return ""; }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code != REQ_PERM) return;
        try { emit(new JSONObject().put("type", "perm").put("granted", fine())); } catch (Exception ignored) { }
        if (tele != null) { tele.stop(); tele = null; }
        watchDataSim();
        forceCells = true;
        emitState(true);
        emitSig(true);
        requestCells();
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        if (!receiversOn) {
            IntentFilter f = new IntentFilter();
            f.addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED);
            f.addAction(LocationManager.PROVIDERS_CHANGED_ACTION);
            f.addAction(ConnectivityManager.ACTION_RESTRICT_BACKGROUND_CHANGED);
            registerReceiver(rx, f);
            receiversOn = true;
        }
        watchDataSim();
        ui.removeCallbacks(tick);
        lastCellsAt = 0; lastStateAt = SystemClock.elapsedRealtime();
        ui.post(tick);
        try { emit(new JSONObject().put("type", "resume")); } catch (Exception ignored) { }
    }

    @Override
    protected void onPause() {
        resumed = false;
        ui.removeCallbacks(tick);
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (receiversOn) { try { unregisterReceiver(rx); } catch (Exception ignored) { } receiversOn = false; }
        try { cm.unregisterNetworkCallback(defCb); } catch (Exception ignored) { }
        if (tele != null) tele.stop();
        new Thread(this::releaseCell).start();
        net.speedStop();
        bg.shutdown();
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        web.evaluateJavascript("window.__wBack ? window.__wBack() : false", v -> { if (!"true".equals(v)) moveTaskToBack(true); });
    }

    final class Bridge {
        @JavascriptInterface
        public String insets() {
            int top = insetTop;
            if (top == 0) { int id = getResources().getIdentifier("status_bar_height", "dimen", "android"); if (id > 0) top = getResources().getDimensionPixelSize(id); }
            return "{\"top\":" + Math.round(top / getResources().getDisplayMetrics().density) + "}";
        }

        @JavascriptInterface public String state() { String s = MainActivity.this.state().toString(); lastState = s; return s; }

        @JavascriptInterface public String cells() { return fine() ? Radio.cells(cached()).toString() : "[]"; }

        @JavascriptInterface
        public String refresh() {
            if (!fine()) return "noperm";
            if (airplane()) return "error";
            forceCells = true;
            ui.post(MainActivity.this::requestCells);
            return "ok";
        }

        @JavascriptInterface
        public void live(boolean on) { ui.post(() -> { live = on; if (resumed) { ui.removeCallbacks(tick); ui.post(tick); } }); }

        @JavascriptInterface public void ping(String id, String host, int count) { net.ping(id, host, count); }
        @JavascriptInterface public void speedStart() { net.speed(); }
        @JavascriptInterface public void speedStop() { net.speedStop(); }

        @JavascriptInterface
        public void turbo(boolean on) {
            ui.post(() -> {
                if (on) {
                    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED && !prefs.getBoolean("askedNotif", false)) {
                        prefs.edit().putBoolean("askedNotif", true).apply();
                        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
                    }
                    TurboService.start(MainActivity.this);
                } else TurboService.stop(MainActivity.this);
            });
        }

        @JavascriptInterface public boolean turboOn() { return TurboService.running; }

        @JavascriptInterface
        public boolean open(String kind) {
            final boolean[] r = {false};
            CountDownLatch l = new CountDownLatch(1);
            ui.post(() -> { r[0] = openSettings(kind); l.countDown(); });
            try { l.await(2, TimeUnit.SECONDS); } catch (InterruptedException ignored) { }
            return r[0];
        }

        @JavascriptInterface
        public String netMode() {
            final String[] r = {"fail"};
            CountDownLatch l = new CountDownLatch(1);
            ui.post(() -> { r[0] = MainActivity.this.netMode(); l.countDown(); });
            try { l.await(2, TimeUnit.SECONDS); } catch (InterruptedException ignored) { }
            return r[0];
        }

        @JavascriptInterface
        public void askPerm() {
            ui.post(() -> {
                if (prefs.getBoolean("askedPerm", false) && !fine() && !shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION)) {
                    openSettings("app");
                    return;
                }
                prefs.edit().putBoolean("askedPerm", true).apply();
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.READ_PHONE_STATE}, REQ_PERM);
            });
        }

        @JavascriptInterface public String loc() { return lastLocation(); }
        @JavascriptInterface public void openUrl(String u) { ui.post(() -> MainActivity.this.openUrl(u)); }

        @JavascriptInterface
        public void share(String text) {
            ui.post(() -> {
                Intent i = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text);
                try { startActivity(Intent.createChooser(i, "Поделиться")); } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface
        public void copy(String text) {
            ui.post(() -> { ClipboardManager c = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE); if (c != null) c.setPrimaryClip(ClipData.newPlainText("Neon Signal", text)); });
        }

        @JavascriptInterface public void toast(String t) { ui.post(() -> Toast.makeText(MainActivity.this, t, Toast.LENGTH_SHORT).show()); }

        @JavascriptInterface
        @SuppressWarnings("deprecation")
        public void vibrate(int ms) {
            try { Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE); if (v != null && v.hasVibrator()) v.vibrate(VibrationEffect.createOneShot(Math.max(10, ms), VibrationEffect.DEFAULT_AMPLITUDE)); } catch (Exception ignored) { }
        }

        @JavascriptInterface public String version() { return BuildConfig.VERSION_NAME; }
    }
}
