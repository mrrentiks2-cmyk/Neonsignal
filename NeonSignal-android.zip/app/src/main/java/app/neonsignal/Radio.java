package app.neonsignal;

import android.os.Build;
import android.telephony.CellIdentityGsm;
import android.telephony.CellIdentityLte;
import android.telephony.CellIdentityNr;
import android.telephony.CellIdentityTdscdma;
import android.telephony.CellIdentityWcdma;
import android.telephony.CellInfo;
import android.telephony.CellInfoCdma;
import android.telephony.CellInfoGsm;
import android.telephony.CellInfoLte;
import android.telephony.CellInfoNr;
import android.telephony.CellInfoTdscdma;
import android.telephony.CellInfoWcdma;
import android.telephony.CellSignalStrength;
import android.telephony.CellSignalStrengthCdma;
import android.telephony.CellSignalStrengthGsm;
import android.telephony.CellSignalStrengthLte;
import android.telephony.CellSignalStrengthNr;
import android.telephony.CellSignalStrengthTdscdma;
import android.telephony.CellSignalStrengthWcdma;
import android.telephony.SignalStrength;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

/** Turns Android cell objects into small JSON records for the web UI. */
final class Radio {
    static final int NA = Integer.MAX_VALUE;

    private Radio() { }

    private static void put(JSONObject o, String k, int v, int lo, int hi) {
        if (v == NA || v == Integer.MIN_VALUE || v < lo || v > hi) return;
        try { o.put(k, v); } catch (Exception ignored) { }
    }

    private static void put(JSONObject o, String k, long v, long lo, long hi) {
        if (v == Long.MAX_VALUE || v == NA || v < lo || v > hi) return;
        try { o.put(k, v); } catch (Exception ignored) { }
    }

    private static void put(JSONObject o, String k, Object v) {
        if (v == null) return;
        if (v instanceof CharSequence && ((CharSequence) v).length() == 0) return;
        try { o.put(k, v instanceof CharSequence ? v.toString() : v); } catch (Exception ignored) { }
    }

    /** some modems still report SINR in 0.1 dB */
    private static int sinr(int v) { return v == NA ? NA : Math.abs(v) > 40 ? Math.round(v / 10f) : v; }

    static JSONArray cells(List<CellInfo> list) {
        JSONArray a = new JSONArray();
        if (list == null) return a;
        for (CellInfo ci : list) {
            try { JSONObject o = cell(ci); if (o != null) a.put(o); } catch (Exception ignored) { }
        }
        return a;
    }

    static JSONObject cell(CellInfo ci) {
        JSONObject o = new JSONObject();
        put(o, "reg", ci.isRegistered());
        if (Build.VERSION.SDK_INT >= 28) put(o, "st", ci.getCellConnectionStatus(), 0, 3);
        if (ci instanceof CellInfoLte) {
            CellIdentityLte id = ((CellInfoLte) ci).getCellIdentity();
            put(o, "tech", "LTE");
            put(o, "ci", id.getCi(), 0, 268435455);
            put(o, "tac", id.getTac(), 0, 65535);
            put(o, "pci", id.getPci(), 0, 503);
            put(o, "arfcn", id.getEarfcn(), 0, 262143);
            if (Build.VERSION.SDK_INT >= 28) {
                put(o, "bw", id.getBandwidth(), 1, 100000);
                put(o, "mcc", id.getMccString()); put(o, "mnc", id.getMncString());
                put(o, "op", id.getOperatorAlphaShort());
            }
            if (Build.VERSION.SDK_INT >= 30) put(o, "bands", toArr(id.getBands()));
            lte(o, ((CellInfoLte) ci).getCellSignalStrength());
        } else if (Build.VERSION.SDK_INT >= 29 && ci instanceof CellInfoNr) {
            CellIdentityNr id = (CellIdentityNr) ((CellInfoNr) ci).getCellIdentity();
            put(o, "tech", "NR");
            put(o, "ci", id.getNci(), 0, 68719476735L);
            put(o, "tac", id.getTac(), 0, 16777215);
            put(o, "pci", id.getPci(), 0, 1007);
            put(o, "arfcn", id.getNrarfcn(), 0, 3279165);
            put(o, "mcc", id.getMccString()); put(o, "mnc", id.getMncString());
            put(o, "op", id.getOperatorAlphaShort());
            if (Build.VERSION.SDK_INT >= 30) put(o, "bands", toArr(id.getBands()));
            nr(o, (CellSignalStrengthNr) ((CellInfoNr) ci).getCellSignalStrength());
        } else if (ci instanceof CellInfoWcdma) {
            CellIdentityWcdma id = ((CellInfoWcdma) ci).getCellIdentity();
            put(o, "tech", "WCDMA");
            put(o, "ci", id.getCid(), 0, 268435455);
            put(o, "tac", id.getLac(), 0, 65535);
            put(o, "pci", id.getPsc(), 0, 511);
            put(o, "arfcn", id.getUarfcn(), 0, 16383);
            if (Build.VERSION.SDK_INT >= 28) { put(o, "mcc", id.getMccString()); put(o, "mnc", id.getMncString()); put(o, "op", id.getOperatorAlphaShort()); }
            wcdma(o, ((CellInfoWcdma) ci).getCellSignalStrength());
        } else if (ci instanceof CellInfoGsm) {
            CellIdentityGsm id = ((CellInfoGsm) ci).getCellIdentity();
            put(o, "tech", "GSM");
            put(o, "ci", id.getCid(), 0, 65535);
            put(o, "tac", id.getLac(), 0, 65535);
            put(o, "pci", id.getBsic(), 0, 63);
            put(o, "arfcn", id.getArfcn(), 0, 65535);
            if (Build.VERSION.SDK_INT >= 28) { put(o, "mcc", id.getMccString()); put(o, "mnc", id.getMncString()); put(o, "op", id.getOperatorAlphaShort()); }
            gsm(o, ((CellInfoGsm) ci).getCellSignalStrength());
        } else if (Build.VERSION.SDK_INT >= 29 && ci instanceof CellInfoTdscdma) {
            CellIdentityTdscdma id = ((CellInfoTdscdma) ci).getCellIdentity();
            put(o, "tech", "TDSCDMA");
            put(o, "ci", id.getCid(), 0, 268435455);
            put(o, "tac", id.getLac(), 0, 65535);
            put(o, "pci", id.getCpid(), 0, 127);
            put(o, "arfcn", id.getUarfcn(), 0, 65535);
            put(o, "mcc", id.getMccString()); put(o, "mnc", id.getMncString());
            CellSignalStrengthTdscdma s = ((CellInfoTdscdma) ci).getCellSignalStrength();
            put(o, "dbm", s.getDbm(), -130, -20);
            put(o, "level", s.getLevel(), 0, 4);
        } else if (ci instanceof CellInfoCdma) {
            put(o, "tech", "CDMA");
            CellSignalStrengthCdma s = ((CellInfoCdma) ci).getCellSignalStrength();
            put(o, "dbm", s.getDbm(), -130, -20);
            put(o, "level", s.getLevel(), 0, 4);
        } else return null;
        return o;
    }

    private static JSONArray toArr(int[] v) {
        if (v == null || v.length == 0) return null;
        JSONArray a = new JSONArray();
        for (int x : v) a.put(x);
        return a;
    }

    static void lte(JSONObject o, CellSignalStrengthLte s) {
        put(o, "rsrp", s.getRsrp(), -140, -43);
        put(o, "rsrq", s.getRsrq(), -34, 3);
        put(o, "sinr", sinr(s.getRssnr()), -20, 40);
        if (Build.VERSION.SDK_INT >= 29) put(o, "rssi", s.getRssi(), -113, -25);
        put(o, "ta", s.getTimingAdvance(), 0, 1282);
        put(o, "dbm", s.getDbm(), -140, -20);
        put(o, "level", s.getLevel(), 0, 4);
    }

    static void nr(JSONObject o, CellSignalStrengthNr s) {
        int rsrp = s.getSsRsrp(), rsrq = s.getSsRsrq(), sn = s.getSsSinr();
        if (rsrp == NA) { rsrp = s.getCsiRsrp(); rsrq = s.getCsiRsrq(); sn = s.getCsiSinr(); }
        put(o, "rsrp", rsrp, -156, -31);
        put(o, "rsrq", rsrq, -43, 20);
        put(o, "sinr", sinr(sn), -23, 40);
        put(o, "dbm", s.getDbm(), -156, -20);
        put(o, "level", s.getLevel(), 0, 4);
    }

    static void wcdma(JSONObject o, CellSignalStrengthWcdma s) {
        put(o, "dbm", s.getDbm(), -125, -20);
        if (Build.VERSION.SDK_INT >= 30) put(o, "ecno", s.getEcNo(), -24, 1);
        put(o, "level", s.getLevel(), 0, 4);
    }

    static void gsm(JSONObject o, CellSignalStrengthGsm s) {
        put(o, "dbm", s.getDbm(), -125, -20);
        put(o, "ta", s.getTimingAdvance(), 0, 219);
        put(o, "level", s.getLevel(), 0, 4);
    }

    /** current signal of a subscription (API 29+): LTE anchor first, NR attached in NSA */
    static JSONObject sig(SignalStrength ss) {
        if (ss == null || Build.VERSION.SDK_INT < 29) return null;
        JSONObject main = null, nr = null;
        int rank = -1;
        for (CellSignalStrength c : ss.getCellSignalStrengths()) {
            JSONObject o = new JSONObject();
            int r;
            if (c instanceof CellSignalStrengthLte) { put(o, "tech", "LTE"); lte(o, (CellSignalStrengthLte) c); r = 4; }
            else if (c instanceof CellSignalStrengthNr) { put(o, "tech", "NR"); nr(o, (CellSignalStrengthNr) c); r = 3; if (o.has("rsrp")) nr = o; }
            else if (c instanceof CellSignalStrengthWcdma) { put(o, "tech", "WCDMA"); wcdma(o, (CellSignalStrengthWcdma) c); r = 2; }
            else if (c instanceof CellSignalStrengthTdscdma) { put(o, "tech", "TDSCDMA"); put(o, "dbm", c.getDbm(), -130, -20); put(o, "level", c.getLevel(), 0, 4); r = 2; }
            else if (c instanceof CellSignalStrengthGsm) { put(o, "tech", "GSM"); gsm(o, (CellSignalStrengthGsm) c); r = 1; }
            else if (c instanceof CellSignalStrengthCdma) { put(o, "tech", "CDMA"); put(o, "dbm", c.getDbm(), -130, -20); r = 0; }
            else continue;
            if (!o.has("rsrp") && !o.has("dbm")) continue;
            if (r > rank) { rank = r; main = o; }
        }
        if (main != null && nr != null && main != nr) put(main, "nr", nr);
        return main;
    }
}
